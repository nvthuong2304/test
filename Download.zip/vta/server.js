require('dotenv').config({ path: __dirname + '/.env' });
const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const path = require('path');
const cors = require('cors');
const { Telegraf } = require('telegraf');

const PORT = process.env.PORT || 8011; 
const BOT_TOKEN = process.env.BOT_TOKEN || ""; 
const bot = new Telegraf(BOT_TOKEN);
const app = express();

app.set('trust proxy', 1);

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'web')));

const dbPath = '/root/vt/vuongtrieu.db'; 
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) console.error("Lỗi kết nối DB Admin:", err.message);
    else console.log("Admin đã kết nối thành công với Database của Miniapp tại /root/vt/vuongtrieu.db");
});

db.serialize(() => {
    db.run("PRAGMA journal_mode = WAL;");
    db.run("PRAGMA busy_timeout = 5000;");

    db.run(`CREATE TABLE IF NOT EXISTS system_config (key TEXT PRIMARY KEY, value TEXT)`);
    
    const addCol = (table, col, type) => { db.run(`ALTER TABLE ${table} ADD COLUMN ${col} ${type}`, () => {}); };
    
    addCol('buildings', 'effect_name', 'TEXT'); addCol('users', 'ban_status', 'INTEGER DEFAULT 0');
    addCol('users', 'is_special', 'INTEGER DEFAULT 0'); addCol('users', 'device_code', 'TEXT');
    addCol('users', 'join_date', 'TEXT'); addCol('withdrawals', 'reject_reason', 'TEXT');
    addCol('withdrawals', 'is_refunded', 'INTEGER DEFAULT 0');

    db.run(`CREATE TABLE IF NOT EXISTS user_history (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT, type TEXT, details TEXT, created_at INTEGER)`);
    db.run(`CREATE TABLE IF NOT EXISTS chat_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT, sender TEXT, message TEXT, created_at INTEGER, is_read INTEGER DEFAULT 0)`);
    db.run(`CREATE TABLE IF NOT EXISTS advanced_giftcodes (code TEXT PRIMARY KEY, type TEXT, max_uses INTEGER, uses INTEGER DEFAULT 0, reward_data TEXT, expires_at INTEGER)`);

    db.run(`INSERT OR IGNORE INTO system_config (key, value) VALUES 
        ('cost_tap', '50000'), ('cost_energy', '50000'), ('cost_regen', '100000'),
        ('train_qty_1', '5'), ('train_qty_2', '25'), 
        ('train_cost_food', '10'), ('train_cost_gold', '100'),
        ('battle_base_troops', '5'), ('battle_troops_step', '1'),
        ('battle_base_food', '20'), ('battle_food_step', '5'),
        ('ref_gold_min', '3000'), ('ref_gold_max', '10000'), 
        ('ref_hours', '1'), ('ref_commission', '0.003'),
        ('announcements', '[]'), ('withdraw_channels', ''), ('auto_giftcodes', '[]')
    `);
});

// VÁ LỖI AUTO DROP (Phiên bản BỌC THÉP 2.0 - Không trượt một giây)
setInterval(() => {
    // 1. Ép giờ chuẩn Việt Nam bằng thư viện hệ thống (Chính xác tuyệt đối)
    const vnTime = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Ho_Chi_Minh"}));
    const h = vnTime.getHours().toString().padStart(2, '0');
    const m = vnTime.getMinutes().toString().padStart(2, '0');
    const currentTime = `${h}:${m}`; 
    const currentDate = vnTime.getDate();

    db.get("SELECT value FROM system_config WHERE key='auto_giftcodes'", (err, row) => {
        if (err) return console.error("[AutoDrop] Lỗi đọc DB:", err);
        if (row && row.value) {
            try {
                let configs = JSON.parse(row.value); 
                let updated = false;
                
                configs.forEach(conf => {
                    // 2. Tự động sửa lỗi người dùng gõ sai định dạng (Ví dụ: 8:5 sẽ thành 08:05)
                    let confTime = conf.time;
                    if(confTime && confTime.includes(':')) {
                        let pts = confTime.split(':');
                        confTime = `${pts[0].padStart(2, '0')}:${pts[1].padStart(2, '0')}`;
                    }

                    if (confTime === currentTime && conf.last_run_date !== currentDate && conf.active) {
                        console.log(`\n[AutoDrop] ⏰ Đã đến giờ vàng: ${currentTime}. Tiến hành đúc mã...`);
                        const code = "DROP" + Math.random().toString(36).substr(2, 6).toUpperCase();
                        
                        db.run("INSERT INTO advanced_giftcodes (code, type, max_uses, reward_data, expires_at) VALUES (?, ?, ?, ?, ?)", 
                        [code, conf.type, conf.max_uses, JSON.stringify(conf.reward_data), Date.now() + 24*3600*1000], function(err) {
                            if (err) return console.log("[AutoDrop] ❌ Lỗi đúc code:", err.message);
                            
                            console.log(`[AutoDrop] ✅ Đúc code thành công: ${code}. Đang sai nha dịch gửi lên Kênh: ${conf.channel}...`);
                            
                            let txt = `🎁 *QUAN PHỦ BAN PHÁT CỐNG PHẨM* 🎁\n\nMã Nhập: \`${code}\`\nGiới hạn: ${conf.max_uses} lượt\n\nNhập ngay kẻo hết hỡi các Lãnh chúa!`;
                            
                            if (conf.channel) {
                                bot.telegram.sendMessage(conf.channel, txt, { parse_mode: 'Markdown' })
                                    .then(() => console.log(`[AutoDrop] 🚀 Đã bắn tin nhắn lên kênh ${conf.channel} thành công!`))
                                    .catch(e => console.log(`[AutoDrop] ⚠️ LỖI TELEGRAM KHÔNG CHO GỬI (Kênh sai ID, chưa set Admin, hoặc bị cấm):`, e.message));
                            } else {
                                console.log("[AutoDrop] ⚠️ Cảnh báo: Ngài chưa điền ID Kênh để gửi!");
                            }
                        });
                        
                        conf.last_run_date = currentDate; 
                        updated = true;
                    }
                });
                
                if (updated) {
                    db.run("UPDATE system_config SET value=? WHERE key='auto_giftcodes'", [JSON.stringify(configs)]);
                }
            } catch(e) {
                console.error("[AutoDrop] ❌ Lỗi xử lý JSON:", e.message);
            }
        }
    });
}, 30000); // Rút ngắn nhịp tim xuống 30s/lần để đảm bảo không bao giờ trượt phút nào!

const ADMIN_PASS = process.env.ADMIN_PASS;
const verifyAdmin = (req, res, next) => {
    if (req.body.admin_pass !== ADMIN_PASS) return res.json({ success: false, msg: "Sai Mật khẩu Quản trị!" });
    next();
};

app.post('/api/admin/stats', verifyAdmin, (req, res) => {
    db.get("SELECT COUNT(*) as totalUsers, SUM(gold) as totalGold FROM users", (err, uStats) => {
        db.get("SELECT COUNT(*) as pendingWithdraw FROM withdrawals WHERE status='PENDING'", (err, wStats) => {
            db.get("SELECT COUNT(DISTINCT telegram_id) as unreadChats FROM chat_messages WHERE sender='user' AND is_read=0", (err, cStats) => {
                db.all(`SELECT join_date, COUNT(*) as count FROM users WHERE join_date IS NOT NULL GROUP BY join_date ORDER BY join_date DESC LIMIT 30`, (err, chartData) => {
                                res.json({ 
                                    success: true, 
                                    stats: { 
                                        users: (uStats ? uStats.totalUsers : 0) || 0, 
                                        gold: (uStats ? uStats.totalGold : 0) || 0, 
                                        withdraws: (wStats ? wStats.pendingWithdraw : 0) || 0, 
                                        unread_chats: (cStats ? cStats.unreadChats : 0) || 0 
                                    },
                                    chart: chartData || []
                                });
                });
            });
        });
    });
});

app.post('/api/admin/users/export', verifyAdmin, (req, res) => {
    db.all("SELECT telegram_id, first_name, gold, food, wood, stone, iron, dark_iron, jade, glaze, purple_gold, troops, ban_status FROM users", (err, rows) => {
        if (err) return res.json({success: false});
        let csv = "\uFEFFID,Tên Lãnh Chúa,Vàng,Lương,Gỗ,Đá,Sắt,Huyền Thiết,Linh Ngọc,Lưu Ly,Tử Kim,Lính,Trạng Thái\n";
        rows.forEach(r => {
            let status = r.ban_status === 1 ? 'Bị Cấm' : 'Bình Thường';
            csv += `${r.telegram_id},"${r.first_name}",${r.gold},${r.food||0},${r.wood},${r.stone},${r.iron||0},${r.dark_iron||0},${r.jade||0},${r.glaze||0},${r.purple_gold||0},${r.troops},${status}\n`;
        });
        res.json({success: true, csv});
    });
});

app.post('/api/admin/withdrawals', verifyAdmin, (req, res) => {
    db.all("SELECT w.*, u.first_name FROM withdrawals w LEFT JOIN users u ON w.telegram_id = u.telegram_id ORDER BY CASE WHEN w.status='PENDING' THEN 0 ELSE 1 END, w.created_at ASC", (err, rows) => {
        res.json({ success: true, withdrawals: rows || [] });
    });
});

app.post('/api/admin/withdrawal/update', verifyAdmin, (req, res) => {
    const { id, status, reject_reason, refund_amount, telegram_id, amount, bank_info, first_name } = req.body; 
    db.run("UPDATE withdrawals SET status=?, reject_reason=?, is_refunded=? WHERE id=?", 
        [status, reject_reason || '', refund_amount > 0 ? 1 : 0, id], () => {
        
        const notifyAndRespond = () => {
            db.get("SELECT value FROM system_config WHERE key='withdraw_channels'", (err, row) => {
                if (row && row.value) {
                    const channels = row.value.split(',').map(c => c.trim()).filter(c => c);
                    let msg = "";
                    if (status === 'COMPLETED') {
                        msg = `✅ *THÔNG BÁO XUẤT KHỐ THÀNH CÔNG*\n\n👤 Lãnh chúa: ${first_name}\n💰 Số tiền rút: ${amount.toLocaleString()} Vàng\n🏦 Ngân hàng: \`${bank_info.split('|')[0] || bank_info}\`\n\n🎉 Bổng lộc đã được trao, chúc ngài hùng bá thiên hạ!`;
                    } else if (status === 'REJECTED') {
                        msg = `❌ *TỪ CHỐI ĐƠN XUẤT KHỐ*\n\n👤 Lãnh chúa: ${first_name}\n💰 Đơn rút: ${amount.toLocaleString()} Vàng\n📝 Lý do: ${reject_reason}\n\n${refund_amount > 0 ? '🔄 Tiền đã được hoàn lại vào kho bạc.' : 'Đơn đã bị hủy.'}`;
                    }
                    channels.forEach(ch => { bot.telegram.sendMessage(ch, msg, { parse_mode: 'Markdown' }).catch(e => console.log("Lỗi gửi auto notify bank:", e.message)); });
                }
            });
            res.json({ success: true, msg: `Đã xử lý đơn rút.` });
        };

        if(status === 'REJECTED' && refund_amount > 0) {
            db.run("UPDATE users SET gold = gold + ? WHERE telegram_id = ?", [refund_amount, telegram_id], notifyAndRespond);
        } else { notifyAndRespond(); }
    });
});

app.post('/api/admin/config/get', verifyAdmin, (req, res) => {
    db.all("SELECT * FROM system_config", (err, confRows) => {
        let config = {};
        if(confRows) confRows.forEach(r => config[r.key] = r.value);
        db.all("SELECT * FROM tasks", (err, tasks) => { res.json({success: true, config, tasks: tasks || []}); });
    });
});

app.post('/api/admin/config/save', verifyAdmin, (req, res) => {
    const data = req.body.config_data;
    db.serialize(() => {
        for(let key in data) { 
            db.run("REPLACE INTO system_config (key, value) VALUES (?, ?)", [key, data[key]]); 
        }
    });
    res.json({success: true, msg: "Lưu cấu hình thành công!"});
});

app.post('/api/admin/announcement/get', verifyAdmin, (req, res) => {
    db.get("SELECT value FROM system_config WHERE key='announcements'", (err, row) => {
        try { res.json({success: true, data: row ? JSON.parse(row.value) : []}); } catch(e) { res.json({success: true, data: []}); }
    });
});

app.post('/api/admin/announcement/save', verifyAdmin, (req, res) => {
    const announcements = JSON.stringify(req.body.announcements || []);
    db.run("REPLACE INTO system_config (key, value) VALUES ('announcements', ?)", 
    [announcements], () => { res.json({success: true, msg: 'Đã lưu cấu hình thông báo!'}); });
});

app.post('/api/admin/lookup', verifyAdmin, (req, res) => {
    const { target_id } = req.body;
    db.get("SELECT * FROM users WHERE telegram_id=?", [target_id], (err, u) => {
        if(!u) return res.json({success: false, msg: "Không tìm thấy Lãnh chúa này!"});
        db.all("SELECT b.id, b.name, IFNULL(ub.qty, 0) as level FROM buildings b LEFT JOIN user_buildings ub ON b.id = ub.building_id AND ub.telegram_id = ?", [target_id], (err, inventory) => {
            db.all("SELECT * FROM user_history WHERE telegram_id=? ORDER BY created_at DESC LIMIT 1000", [target_id], (err, history) => {
                u.inventory = inventory || []; u.history = history || []; res.json({success: true, user: u});
            });
        });
    });
});

app.post('/api/admin/lookup/update', verifyAdmin, (req, res) => {
    const { target_id, stats, buildings } = req.body;
    let sqlStats = "UPDATE users SET "; let paramsStats = [];
    
    const allowedStats = ['gold', 'food', 'wood', 'stone', 'iron', 'troops', 'dark_iron', 'jade', 'glaze', 'purple_gold', 'tap_level', 'max_energy', 'regen_level'];
    for(let key in stats) { 
        if (allowedStats.includes(key)) {
            let adj = parseFloat(stats[key]);
            if (!isNaN(adj) && adj !== 0) {
                // Sửa thành Cộng/Trừ (+/-) thông số hiện tại, đảm bảo không bị âm (MAX 0)
                sqlStats += `${key}=MAX(0, IFNULL(${key}, 0) + ?), `; 
                paramsStats.push(adj); 
            }
        }
    }
    
    let hasStatsChange = paramsStats.length > 0;

    const updateBuildings = () => {
        if(buildings && buildings.length > 0) {
            db.serialize(() => { 
                buildings.forEach(b => { 
                    let adj = parseInt(b.level_adj);
                    if (!isNaN(adj) && adj !== 0) {
                        db.run("UPDATE user_buildings SET qty=MAX(0, IFNULL(qty, 0) + ?) WHERE telegram_id=? AND building_id=?", [adj, target_id, b.id], function(err) {
                            if (this.changes === 0 && adj > 0) {
                                db.run("INSERT INTO user_buildings (telegram_id, building_id, qty) VALUES (?, ?, ?)", [target_id, b.id, adj]);
                            }
                        });
                    }
                }); 
            });
        }
        res.json({success: true, msg: "Cập nhật hồ sơ thành công!"});
    };

    if (hasStatsChange) {
        sqlStats = sqlStats.slice(0, -2) + " WHERE telegram_id=?"; paramsStats.push(target_id);
        db.run(sqlStats, paramsStats, updateBuildings);
    } else {
        updateBuildings();
    }
});

app.post('/api/admin/lookup/toggle_status', verifyAdmin, (req, res) => {
    const { target_id, field, value } = req.body; 
    const allowedFields = ['ban_status', 'is_special'];
    if (!allowedFields.includes(field)) return res.json({success: false, msg: "Lỗi bảo mật: Trường dữ liệu không hợp lệ!"});

    db.run(`UPDATE users SET ${field}=? WHERE telegram_id=?`, [value, target_id], () => { res.json({success: true, msg: "Đã thay đổi trạng thái!"}); });
});

app.post('/api/admin/giftcode/create', verifyAdmin, async (req, res) => {
    const { code, type, max_uses, reward_data, auto_post, channel_id } = req.body;
    db.run("INSERT INTO advanced_giftcodes (code, type, max_uses, reward_data, expires_at) VALUES (?, ?, ?, ?, ?)", 
    [code, type, max_uses, JSON.stringify(reward_data), Date.now() + 30*24*3600*1000], async (err) => {
        if(err) return res.json({success: false, msg: "Mã Giftcode đã tồn tại!"});
        if(auto_post && channel_id) {
            try {
                let txt = `🎁 *GIFTCODE MỚI BAN HÀNH* 🎁\n\nMã Cống Phẩm: \`${code}\`\nGiới hạn: ${max_uses} lượt nhập\n\nTham gia Vương Triều ngay để nhận bổng lộc!`;
                await bot.telegram.sendMessage(channel_id, txt, { parse_mode: 'Markdown' });
            } catch(e) { return res.json({success: true, msg: "Tạo Code thành công, nhưng Bot chưa có quyền gửi vào Kênh/Nhóm đó!"}); }
        }
        res.json({success: true, msg: "Tạo Giftcode thành công!"});
    });
});

app.post('/api/admin/giftcode/list', verifyAdmin, (req, res) => {
    db.all("SELECT * FROM advanced_giftcodes ORDER BY expires_at DESC", (err, rows) => { res.json({success: true, giftcodes: rows || []}); });
});

app.post('/api/admin/giftcode/delete', verifyAdmin, (req, res) => {
    db.run("DELETE FROM advanced_giftcodes WHERE code=?", [req.body.code], () => { res.json({success: true, msg: "Xóa Code thành công!"}); });
});

app.post('/api/admin/chat/list', verifyAdmin, (req, res) => {
    db.all(`
        SELECT c.telegram_id, u.first_name, u.hide_avatar, c.message, c.created_at,
        (SELECT COUNT(*) FROM chat_messages WHERE telegram_id=c.telegram_id AND sender='user' AND is_read=0) as unread
        FROM chat_messages c
        JOIN users u ON c.telegram_id = u.telegram_id
        WHERE c.id IN (SELECT MAX(id) FROM chat_messages GROUP BY telegram_id)
        ORDER BY c.created_at DESC
    `, (err, rows) => { res.json({success: true, chats: rows || []}); });
});

app.post('/api/admin/chat/messages', verifyAdmin, (req, res) => {
    const { target_id } = req.body;
    db.run("UPDATE chat_messages SET is_read=1 WHERE telegram_id=? AND sender='user'", [target_id]);
    db.all("SELECT * FROM chat_messages WHERE telegram_id=? ORDER BY created_at ASC", [target_id], (err, rows) => { res.json({success: true, messages: rows || []}); });
});

app.post('/api/admin/chat/reply', verifyAdmin, (req, res) => {
    const { target_id, message } = req.body;
    db.run("INSERT INTO chat_messages (telegram_id, sender, message, created_at) VALUES (?, 'admin', ?, ?)", 
        [target_id, message, Date.now()], () => { res.json({success: true}); });
});

app.post('/api/admin/longthe/task/add', verifyAdmin, (req, res) => {
    const { title, link, reward_type, reward_data } = req.body;
    db.run("INSERT INTO tasks (title, link, reward_type, reward_data) VALUES (?, ?, ?, ?)", [title, link, reward_type, JSON.stringify(reward_data)], () => { res.json({success: true, msg: "Thêm thành công!"}); });
});
app.post('/api/admin/longthe/task/del', verifyAdmin, (req, res) => {
    db.run("DELETE FROM tasks WHERE id=?", [req.body.id], () => { res.json({success: true, msg: "Xóa thành công!"}); });
});

app.post('/api/admin/buildings', verifyAdmin, (req, res) => { db.all("SELECT * FROM buildings", (err, rows) => { res.json({ success: true, buildings: rows || [] }); }); });

app.post('/api/admin/building/add', verifyAdmin, (req, res) => {
    const { id, name, description, req_palace, base_time, effect_type, effect_name, base_val } = req.body;
    
    if (effect_type && !/^[a-zA-Z0-9_]+$/.test(effect_type)) {
        return res.json({success: false, msg: "Mã tài nguyên không hợp lệ! Chỉ dùng chữ cái và gạch dưới."});
    }

    db.run(`INSERT INTO buildings (id, name, description, req_palace, base_time, base_wood, base_stone, base_iron, base_dark_iron, base_jade, base_glaze, base_purple_gold, effect_type, base_val, effect_name) VALUES (?, ?, ?, ?, ?, 0, 0, 0, 0, 0, 0, 0, ?, ?, ?)`, 
    [id, name, description, req_palace, base_time, effect_type, base_val, effect_name], (err) => {
        if(err) return res.json({success: false, msg: "ID đã tồn tại!"});
        if (effect_type && !['troops', 'winrate', 'save_troops', 'energy_regen', 'discount_train'].includes(effect_type)) {
            db.run(`ALTER TABLE users ADD COLUMN ${effect_type} REAL DEFAULT 0`, () => {}); 
            db.run(`ALTER TABLE users ADD COLUMN ${effect_type}_rate REAL DEFAULT 0`, () => {});
        }
        res.json({success: true, msg: "Tạo công trình mới thành công!"});
    });
});

app.post('/api/admin/building/update', verifyAdmin, (req, res) => {
    const { id, name, req_palace, base_time, base_wood, base_stone, base_iron, base_dark_iron, base_jade, base_glaze, base_purple_gold, effect_type, effect_name, base_val } = req.body;
    
    if (effect_type && !/^[a-zA-Z0-9_]+$/.test(effect_type)) {
        return res.json({success: false, msg: "Mã tài nguyên không hợp lệ!"});
    }

    db.run(`UPDATE buildings SET name=?, req_palace=?, base_time=?, base_wood=?, base_stone=?, base_iron=?, base_dark_iron=?, base_jade=?, base_glaze=?, base_purple_gold=?, effect_type=?, effect_name=?, base_val=? WHERE id=?`,
    [name, req_palace, base_time, base_wood, base_stone, base_iron, base_dark_iron, base_jade, base_glaze, base_purple_gold, effect_type, effect_name, base_val, id], (err) => {
        if (effect_type && !['troops', 'winrate', 'save_troops', 'energy_regen', 'discount_train'].includes(effect_type)) {
            db.run(`ALTER TABLE users ADD COLUMN ${effect_type} REAL DEFAULT 0`, () => {}); 
            db.run(`ALTER TABLE users ADD COLUMN ${effect_type}_rate REAL DEFAULT 0`, () => {});
        }
        res.json({success: true, msg: "Cập nhật công trình thành công!"});
    });
});

app.post('/api/admin/building/delete', verifyAdmin, (req, res) => {
    const defaultIds = ['palace', 'kitchen', 'barracks', 'ironmine', 'forge', 'lumber', 'quarry', 'darkiron_mine', 'hospital', 'jade_cave', 'observatory', 'smelter', 'glazekiln', 'purplegold_mine'];
    if(defaultIds.includes(req.body.id)) return res.json({success: false, msg: "Không thể xóa công trình gốc!"});
    db.run(`DELETE FROM buildings WHERE id=?`, [req.body.id], () => { res.json({success: true, msg: "Đã xóa!"}); });
});

app.use((req, res) => { res.sendFile(path.join(__dirname, 'web', 'index.html')); });
app.listen(PORT, '0.0.0.0', () => console.log(`[ADMIN] Đang chạy trên cổng ${PORT}`));
